<?php 
require('plantilla.php');
require('objetos.php');

?>